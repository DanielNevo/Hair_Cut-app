package com.example.haircut;

import static android.widget.Toast.makeText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.media.RemoteController;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MangerPage extends AppCompatActivity {

//    FirebaseDatabase rootNode;
//    DatabaseReference reference;

    TextView selectdate;
    ListView mListView;
    ArrayList<String>time;
    private static final String TAG = "MangerPage";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manger_page);
        Log.d(TAG, "oncreate:started.");
        //ListView mListView = (ListView) findViewById(R.id.list);
       // Button delete = (Button) findViewById(R.id.remove);
        CalendarView calendarView = (CalendarView) findViewById(R.id.calendarView);
          Button sick=(Button)findViewById(R.id.sickday);
        TextView selectdate = findViewById(R.id.selectdate);
        //get from the registr new client
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String phone = intent.getStringExtra("phone");
//        String time = intent.getStringExtra("time");
        String date = intent.getStringExtra("date");

        //all the key
        ArrayList<String> time=new ArrayList<String>();
        time.add("10:00 10:30");
        time.add("10:30 11:00");
        time.add("11:00 11:30");
        time.add("11:30 12:00");
        time.add("12:00 12:30");
        time.add("12:30 13:00");
        time.add("13:00 13:30");
        time.add("13:30 14:00");
        time.add("14:00 14:30");
        time.add("14:30 15:00");
        time.add("15:00 15:30");
        time.add("15:30 16:00");
        time.add("16:00 16:30");
        time.add("16:30 17:00");
        time.add("17:00 17:30");
        time.add("17:30 18:00");
        Button a=(Button)findViewById(R.id.btn1);
        Button b=(Button)findViewById(R.id.btn2);
        Button c=(Button)findViewById(R.id.btn3);
        Button d=(Button)findViewById(R.id.btn4);
        Button e=(Button)findViewById(R.id.btn5);
        Button f=(Button)findViewById(R.id.btn6);
        Button g=(Button)findViewById(R.id.btn7);
        Button h=(Button)findViewById(R.id.btn8);
        Button i=(Button)findViewById(R.id.btn9);
        Button j=(Button)findViewById(R.id.btn10);
        Button k=(Button)findViewById(R.id.btn11);
        Button l=(Button)findViewById(R.id.btn12);
        Button m=(Button)findViewById(R.id.btn13);
        Button n=(Button)findViewById(R.id.btn14);
        Button o=(Button)findViewById(R.id.btn15);
        Button p=(Button)findViewById(R.id.btn16);
        //all the buttons
        ArrayList<Button> x=new ArrayList<Button>();
        x.add(a);
        x.add(b);
        x.add(c);
        x.add(d);
        x.add(e);
        x.add(f);
        x.add(g);
        x.add(h);
        x.add(i);
        x.add(j);
        x.add(k);
        x.add(l);
        x.add(m);
        x.add(n);
        x.add(o);
        x.add(p);

        //Create the person objects

        // Client one=new Client("danie","10:00","0542590034");
//        Client one1 = new Client("-", "10:00 10:30", "-");
//        Client one2 = new Client("-", "10:30 11:00", "-");
//        Client one3 = new Client("-", "11:00 11:30", "-");
//        Client one4 = new Client("-", "11:30 12:00", "-");
//        Client one5 = new Client("-", "12:00 12:30", "-");
//        Client one6 = new Client("-", "12:30 13:00", "-");
//        Client one7 = new Client("-", "13:00 13:30", "-");
//        Client one8 = new Client("-", "13:30 14:00", "-");
//        Client one9 = new Client("-", "14:00 14:30", "-");
//        Client one10 = new Client("-", "14:30 15:00", "-");
//        Client one11 = new Client("-", "15:00 15:30", "-");
//        Client one12 = new Client("-", "15:00 16:00", "-");
//        Client one13 = new Client("-", "16:00 16:30", "-");
//        Client one14 = new Client("-", "16:30 17:00", "-");
//        Client one15 = new Client("-", "17:00 17:30", "-");
//        Client one16 = new Client("-", "17:30 18:00", "-");
//
//
//        Client one = new Client(name, time, phone);
//
//
//        //add the client to the list
//        ArrayList<Client> pepolelist = new ArrayList<>();
//        pepolelist.add(one1);
//        pepolelist.add(one2);
//        pepolelist.add(one3);
//        pepolelist.add(one4);
//        pepolelist.add(one5);
//        pepolelist.add(one6);
//        pepolelist.add(one7);
//        pepolelist.add(one8);
//        pepolelist.add(one9);
//        pepolelist.add(one10);
//        pepolelist.add(one11);
//        pepolelist.add(one12);
//        pepolelist.add(one13);
//        pepolelist.add(one14);
//        pepolelist.add(one15);
//        pepolelist.add(one16);


//        ClientListAdapter adapter = new ClientListAdapter(this, R.layout.adapter_view_layout, pepolelist);
//        mListView.setAdapter(adapter);

        // ClientListAdapter adapter1= new ClientListAdapter(this,R.layout.activity_add_view_layout,pepolelist);

        selectdate.setText("please choose date");

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                //update the calnder evrey time i prees
                for (int i=0;i<x.size();i++){
                    Button b=(Button) findViewById(x.get(i).getId());
                        b.setText(time.get(i).toString());
                }
                selectdate.setText(String.valueOf(dayOfMonth)+"-"+ String.valueOf(month+1)+"-"+String.valueOf(year));
                DatabaseReference reference= FirebaseDatabase.getInstance().getReference().child("Date/"+selectdate.getText().toString());
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (Button temp:x) {
                            for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                                Button y = (Button) findViewById(temp.getId());
                                if (snapshot1.getKey().toString().equals(y.getText().toString())) {
                                    y.setText("x");
                                }
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        sick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView date=findViewById(R.id.selectdate);

                Button sick =(Button) v;
                DatabaseReference reference= FirebaseDatabase.getInstance().getReference().child("Date/"+date.getText().toString());
//                reference.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                        for (DataSnapshot snapshot1 : snapshot.getChildren()){
//                            reference.child(snapshot1.getKey().toString()).removeValue();
//                        }
//                    }
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });
                Client one1 = new Client("-", "10:00 10:30", "-");
                reference.child(one1.getTime()).setValue(one1);
                Client one2 = new Client("-", "10:30 11:00", "-");
                reference.child(one2.getTime()).setValue(one2);
                Client one3 = new Client("-", "11:00 11:30", "-");
                reference.child(one3.getTime()).setValue(one3);
                Client one4 = new Client("-", "11:30 12:00", "-");
                reference.child(one4.getTime()).setValue(one4);
                Client one5 = new Client("-", "12:00 12:30", "-");
                reference.child(one5.getTime()).setValue(one5);
                Client one6 = new Client("-", "12:30 13:00", "-");
                reference.child(one6.getTime()).setValue(one6);
                Client one7 = new Client("-", "13:00 13:30", "-");
                reference.child(one7.getTime()).setValue(one7);
                Client one8 = new Client("-", "13:30 14:00", "-");
                reference.child(one8.getTime()).setValue(one8);
                Client one9 = new Client("-", "14:00 14:30", "-");
                reference.child(one9.getTime()).setValue(one9);
                Client one10 = new Client("-", "14:30 15:00", "-");
                reference.child(one10.getTime()).setValue(one10);
                Client one11 = new Client("-", "15:00 15:30", "-");
                reference.child(one11.getTime()).setValue(one11);
                Client one12 = new Client("-", "15:30 16:00", "-");
                reference.child(one12.getTime()).setValue(one12);
                Client one13 = new Client("-", "16:00 16:30", "-");
                reference.child(one13.getTime()).setValue(one13);
                Client one14 = new Client("-", "16:30 17:00", "-");
                reference.child(one14.getTime()).setValue(one14);
                Client one15 = new Client("-", "17:00 17:30", "-");
                reference.child(one15.getTime()).setValue(one15);
                Client one16 = new Client("-", "17:30 18:00", "-");
                reference.child(one16.getTime()).setValue(one16);
            }
        });


        }
    public void meeting(View view) {
        Button but =(Button) view;
        TextView date=findViewById(R.id.selectdate);
        String time=but.getText().toString();
        // String str=b.getText().toString();
        if(!time.equals("x")&&!date.getText().toString().equals("please choose date")) {
            Intent intent = new Intent(this, Client_Registration.class);
            intent.putExtra("date", date.getText().toString());
            intent.putExtra("time", but.getText().toString());
            intent.putExtra("flag","true");
            startActivity(intent);
            but.setText("x");
        }
         else if(time.equals("x")&&!date.getText().toString().equals("please choose date")){
            Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT).show();
            DatabaseReference reference= FirebaseDatabase.getInstance().getReference().child("Date/"+date.getText().toString());
            ArrayList<String> timex=new ArrayList<String>();
            timex.add("10:00 10:30");
            timex.add("10:30 11:00");
            timex.add("11:00 11:30");
            timex.add("11:30 12:00");
            timex.add("12:00 12:30");
            timex.add("12:30 13:00");
            timex.add("13:00 13:30");
            timex.add("13:30 14:00");
            timex.add("14:00 14:30");
            timex.add("14:30 15:00");
            timex.add("15:00 15:30");
            timex.add("15:30 16:00");
            timex.add("16:00 16:30");
            timex.add("16:30 17:00");
            timex.add("17:00 17:30");
            timex.add("17:30 18:00");
            Button a=(Button)findViewById(R.id.btn1);
            Button b=(Button)findViewById(R.id.btn2);
            Button c=(Button)findViewById(R.id.btn3);
            Button d=(Button)findViewById(R.id.btn4);
            Button e=(Button)findViewById(R.id.btn5);
            Button f=(Button)findViewById(R.id.btn6);
            Button g=(Button)findViewById(R.id.btn7);
            Button h=(Button)findViewById(R.id.btn8);
            Button i=(Button)findViewById(R.id.btn9);
            Button j=(Button)findViewById(R.id.btn10);
            Button k=(Button)findViewById(R.id.btn11);
            Button l=(Button)findViewById(R.id.btn12);
            Button m=(Button)findViewById(R.id.btn13);
            Button n=(Button)findViewById(R.id.btn14);
            Button o=(Button)findViewById(R.id.btn15);
            Button p=(Button)findViewById(R.id.btn16);
            //all the buttons
            ArrayList<Button> x=new ArrayList<Button>();
            x.add(a);
            x.add(b);
            x.add(c);
            x.add(d);
            x.add(e);
            x.add(f);
            x.add(g);
            x.add(h);
            x.add(i);
            x.add(j);
            x.add(k);
            x.add(l);
            x.add(m);
            x.add(n);
            x.add(o);
            x.add(p);
                 time="";
                 int z=0;
                 for (Button temp:x){
                   if(but.getId()==temp.getId()){
                       if(z==0){
                           time="10:00 10:30";
                           break;
                       }
                       if(z==1){
                           time="10:30 11:00";
                           break;
                       }
                       if(z==2){
                           time="11:00 11:30";
                           break;
                       }
                       if(z==3){
                           time="11:30 12:00";
                           break;
                       }
                       if(z==4){
                           time="12:00 12:30";
                           break;
                       }
                       if(z==5){
                           time="12:30 13:00";
                           break;
                       }
                       if(z==6){
                           time="13:00 13:30";
                           break;
                       }
                       if(z==7){
                           time="13:30 14:00";
                           break;
                       }
                       if(z==8){
                           time="14:00 14:30";
                           break;
                       }
                       if(z==9){
                           time="14:30 15:00";
                           break;
                       }
                       if(z==10){
                           time="15:00 15:30";
                           break;
                       }
                       if(z==11){
                           time="15:30 16:00";
                           break;
                       }
                       if(z==12){
                           time="16:00 16:30";
                           break;
                       }
                       if(z==13){
                           time="16:30 17:00";
                           break;
                       }
                       if(z==14){
                           time="17:00 17:30";
                           break;
                       }
                       if(z==15){
                           time="17:30 18:00";
                           break;
                       }
               }
                   z++;
           }
                 time=timex.get(z).toString();
            Toast.makeText(getApplicationContext(),time.toString(),Toast.LENGTH_SHORT).show();
            reference.child(time.toString()).removeValue();
            but.setText(time.toString());

        }
        }

    }


