package com.example.haircut;

import android.widget.Button;

import java.sql.Time;

public class Client {
    private String time;
    private String name;
    private String number;

    public Client(String name,String time,String number ) {
        this.time = time;
        this.name = name;
        this.number = number;

    }

    public String getTime() {
        return time;
    }




    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
