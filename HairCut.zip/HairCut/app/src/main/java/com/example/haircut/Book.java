package com.example.haircut;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Book extends AppCompatActivity {
     Date date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);
        CalendarView calendarView=findViewById(R.id.calendarView);
        final TextView selectdate=findViewById(R.id.selectdate);
        FirebaseDatabase instance=FirebaseDatabase.getInstance();
        //all the key
         ArrayList<String> time=new ArrayList<String>();
        time.add("10:00 10:30");
        time.add("10:30 11:00");
        time.add("11:00 11:30");
        time.add("11:30 12:00");
        time.add("12:00 12:30");
        time.add("12:30 13:00");
        time.add("13:00 13:30");
        time.add("13:30 14:00");
        time.add("14:00 14:30");
        time.add("14:30 15:00");
        time.add("15:00 15:30");
        time.add("15:30 16:00");
        time.add("16:00 16:30");
        time.add("16:30 17:00");
        time.add("17:00 17:30");
        time.add("17:30 18:00");
        Button a=(Button)findViewById(R.id.btn1);
        Button b=(Button)findViewById(R.id.btn2);
        Button c=(Button)findViewById(R.id.btn3);
        Button d=(Button)findViewById(R.id.btn4);
        Button e=(Button)findViewById(R.id.btn5);
        Button f=(Button)findViewById(R.id.btn6);
        Button g=(Button)findViewById(R.id.btn7);
        Button h=(Button)findViewById(R.id.btn8);
        Button i=(Button)findViewById(R.id.btn9);
        Button j=(Button)findViewById(R.id.btn10);
        Button k=(Button)findViewById(R.id.btn11);
        Button l=(Button)findViewById(R.id.btn12);
        Button m=(Button)findViewById(R.id.btn13);
        Button n=(Button)findViewById(R.id.btn14);
        Button o=(Button)findViewById(R.id.btn15);
        Button p=(Button)findViewById(R.id.btn16);
        //all the buttons
        ArrayList<Button> x=new ArrayList<Button>();
        x.add(a);
        x.add(b);
        x.add(c);
        x.add(d);
        x.add(e);
        x.add(f);
        x.add(g);
        x.add(h);
        x.add(i);
        x.add(j);
        x.add(k);
        x.add(l);
        x.add(m);
        x.add(n);
        x.add(o);
        x.add(p);

        selectdate.setText("please choose date");

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                //update the calnder evrey time i prees
                for (int i=0;i<x.size();i++){
                    Button b=(Button) findViewById(x.get(i).getId());
                    if(b.getText().toString().equals("x")){
                        b.setText(time.get(i).toString());
                    }
                }
                selectdate.setText(String.valueOf(dayOfMonth)+"-"+ String.valueOf(month+1)+"-"+String.valueOf(year));
                DatabaseReference reference= FirebaseDatabase.getInstance().getReference().child("Date/"+selectdate.getText().toString());
                reference.addValueEventListener(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot snapshot) {
                       for (Button temp:x) {
                           for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                               Button y = (Button) findViewById(temp.getId());
                               if (snapshot1.getKey().toString().equals(y.getText().toString())) {
                                   y.setText("x");
                               }
                           }
                       }
                   }
                   @Override
                   public void onCancelled(@NonNull DatabaseError error) {

                   }
               });
            }
        });
    }


///if we doing meeting
    public void meeting(View view) {
        Button b =(Button) view;
        TextView date=findViewById(R.id.selectdate);
        String time=b.getText().toString();
       // String str=b.getText().toString();
        if(!time.equals("x")&&!date.getText().toString().equals("please choose date")){
            Intent intent=new Intent(this,Client_Registration.class);
            intent.putExtra("date",date.getText().toString());
            intent.putExtra("time",b.getText().toString());
            intent.putExtra("flag","false");
            startActivity(intent);
            b.setText("x");

        }
    }

}