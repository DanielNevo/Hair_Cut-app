package com.example.haircut;

import static android.widget.Button.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Client_Registration extends AppCompatActivity {

    FirebaseDatabase rootNode;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_registration);

        //this is for the date and the time

        Intent intent=getIntent();
        String date=intent.getStringExtra("date");
        String time=intent.getStringExtra("time");
        String flag=intent.getStringExtra("flag");

        TextView timev=findViewById(R.id.time);
        TextView datev=findViewById(R.id.date);
        timev.setText(time);
        datev.setText(date);
        //=========================================
        Button b=findViewById(R.id.idBtnRegister);
        EditText name=findViewById(R.id.name);
        EditText phone=findViewById(R.id.phone);


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              rootNode=FirebaseDatabase.getInstance();
              reference=rootNode.getReference("Date/"+datev.getText().toString());


//            Intent intent1=new Intent(Client_Registration.this,MangerPage.class);
//            intent1.putExtra("name",name.getText().toString());
//            intent1.putExtra("phone",phone.getText().toString());
//            intent1.putExtra("time",time);
//            intent1.putExtra("date",date);
//            startActivity(intent1);
                Client client=new Client(name.getText().toString(),time.toString(),phone.getText().toString());

                reference.child(time.toString()).setValue(client);
                if(flag.equals(false)) {
                    Intent intent2 = new Intent(Client_Registration.this, MainActivity.class);
                    startActivity(intent2);
                }
                else{
                    Intent intent2 = new Intent(Client_Registration.this, MangerPage.class);
                    startActivity(intent2);
                }

            }
       });
    }
}