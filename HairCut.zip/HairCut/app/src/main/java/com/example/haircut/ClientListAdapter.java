package com.example.haircut;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ClientListAdapter extends ArrayAdapter<Client>{
    private static final String TAG="ClientListAdapter";
    private Context mContext;
    int mResource;
    FirebaseDatabase rootNode;
    DatabaseReference reference;

    static class ViewHolder{
        TextView name;
        TextView number;
        TextView time;
        Button delete;
    }

    public ClientListAdapter(Context context, int resource, ArrayList<Client> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource=resource;

    }

    @Override
    public View getView(int position,  View convertView, ViewGroup parent) {

        String time=getItem(position).getTime();
        String name=getItem(position).getName();
        String phone=getItem(position).getNumber();
        Client client=new Client(time,name,phone);

        LayoutInflater inflater=LayoutInflater.from(mContext);
        convertView=inflater.inflate(mResource,parent,false);
        //ViewHolder holder =new ViewHolder();
      //  name=(TextView)convertView.findViewById(R.id.NAME);
     // time=(TextView)convertView.findViewById(R.id.TIME);
       // number=(TextView)convertView.findViewById(R.id.Phone);
        //delete=(Button)convertView.findViewById(R.id.remove);

       // convertView.setTag(holder);
//
        Button delete =(Button)convertView.findViewById(R.id.remove);
        Button add=(Button)convertView.findViewById(R.id.add);
        TextView tvtime=(TextView)convertView.findViewById(R.id.TIME);
        TextView tvname=(TextView)convertView.findViewById(R.id.NAME);
        TextView tvphone=(TextView)convertView.findViewById(R.id.Phone);
        //TextView selectdate=(TextView)convertView.findViewById(R.id.textView);
//        rootNode=FirebaseDatabase.getInstance();
//        reference=rootNode.getReference("Date").child("10-3-22");
        tvphone.setText(phone);
        tvtime.setText(time);
        tvname.setText(name);

        View finalConvertView = convertView;
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"the index is",Toast.LENGTH_SHORT).show();
                 Client c=new Client("",tvtime.getText().toString(),"");
            }
        });
        return convertView;
    }
}
